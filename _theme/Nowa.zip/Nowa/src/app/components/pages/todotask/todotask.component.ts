import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todotask',
  templateUrl: './todotask.component.html',
  styleUrls: ['./todotask.component.scss']
})
export class TodotaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
