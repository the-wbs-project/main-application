import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empty-pages',
  templateUrl: './empty-pages.component.html',
  styleUrls: ['./empty-pages.component.scss']
})
export class EmptyPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
