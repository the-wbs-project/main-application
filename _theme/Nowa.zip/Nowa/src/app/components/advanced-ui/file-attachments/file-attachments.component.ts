import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-attachments',
  templateUrl: './file-attachments.component.html',
  styleUrls: ['./file-attachments.component.scss']
})
export class FileAttachmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
