import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-notification',
  templateUrl: './widget-notification.component.html',
  styleUrls: ['./widget-notification.component.scss']
})
export class WidgetNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
