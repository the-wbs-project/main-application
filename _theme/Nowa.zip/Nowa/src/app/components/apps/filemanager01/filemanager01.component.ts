import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filemanager01',
  templateUrl: './filemanager01.component.html',
  styleUrls: ['./filemanager01.component.scss']
})
export class Filemanager01Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  page =1;
}
