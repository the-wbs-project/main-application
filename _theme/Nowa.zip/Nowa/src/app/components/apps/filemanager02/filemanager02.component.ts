import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filemanager02',
  templateUrl: './filemanager02.component.html',
  styleUrls: ['./filemanager02.component.scss']
})
export class Filemanager02Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  page =1;
}
