import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-typ-icons',
  templateUrl: './typ-icons.component.html',
  styleUrls: ['./typ-icons.component.scss']
})
export class TypIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
