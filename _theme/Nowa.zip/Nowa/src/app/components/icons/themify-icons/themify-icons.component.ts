import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-themify-icons',
  templateUrl: './themify-icons.component.html',
  styleUrls: ['./themify-icons.component.scss']
})
export class ThemifyIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
