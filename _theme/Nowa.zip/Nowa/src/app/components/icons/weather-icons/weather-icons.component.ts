import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weather-icons',
  templateUrl: './weather-icons.component.html',
  styleUrls: ['./weather-icons.component.scss']
})
export class WeatherIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
